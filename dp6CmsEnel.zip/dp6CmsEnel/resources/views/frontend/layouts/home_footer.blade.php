<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <img class="img-fluid" src="https://pandora.pe/ugel/assets/img/logo-footer.png" alt=""
                    style="height: 50px; width: auto;">

            </div>
            <div class="col-md-3">
                <p class="m-0 text-left">
                    <span> <strong class="mb-2">ACCESOS RÁPIDOS</strong></span>
                    <a href="https://pandora.pe/ugel/comunidad-educativa">Comunidad educativa</a><br>
                    <a href="https://pandora.pe/ugel/convocatorias">Convocatorias</a><br>
                    <a href="https://pandora.pe/ugel/control-interno">Sistema de control interno</a><br>
                    <a href="https://pandora.pe/ugel/documentos-generales">Documentos generales</a><br>
                </p>
            </div>

            <div class="col-md-3">
                <p class="m-0 text-left">
                    <span> <strong class="mb-2">ACCESOS RÁPIDOS</strong></span>
                    <a href="https://pandora.pe/ugel/comunidad-educativa">Comunidad educativa</a><br>
                    <a href="https://pandora.pe/ugel/convocatorias">Convocatorias</a><br>
                    <a href="https://pandora.pe/ugel/control-interno">Sistema de control interno</a><br>
                    <a href="https://pandora.pe/ugel/documentos-generales">Documentos generales</a><br>
                </p>
            </div>
            <div class="col-md-3">
                <p class="m-0 text-left">
                    <span> <strong>CONTÁCTANOS</strong></span>
                </p>
                <ul class="redes-sociales">
                    <li><a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a></li>
                </ul>

                <p>Por WhatsApp de 9:00 am hasta 6:00pm<br>
                    <a class="number-ws" href=""><i class="fab fa-whatsapp"></i> 993 652 872 </a>
                </p>



            </div>
        </div>
    </div>
</footer>
