@extends('frontend.layouts.home_layout')
@section('title', 'UGEL ILO')
@section('content')
<div id="myCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
    <div class="carousel-indicators">
        @foreach ($sliders as $key=>$slider)
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="{{  $key }}"
            aria-current="{{ $key === 1 ? 'true' : '' }}" aria-label="Slide {{ $key }}"
            class="{{ $key === 0 ? 'active'  : '' }}"></button>
        @endforeach
    </div>
    <div class="carousel-inner">
        @php
        $i = 1
        @endphp
        @foreach ($sliders as $slider)
        <div class="carousel-item {{ $i === 1 ? 'active': '' }}">
            @php
            $i++
            @endphp
            <img src="{{ $slider->page_image }}" alt="...">
            <div class="container">
                <div class="carousel-caption text-start my-5">
                    <h1>{{ $slider->title }}</h1>
                    <p>{{ $slider->subtitle }}</p>
                    <p><a class="btn btn-lg btn-primary" href="#">+ Información</a></p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>


<div class="pt-5 pb-4 mb-1" id="enlacesdeinteres" style="margin-top: 50px;">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
                <img style="float: left;" src="assets/img/iconenlaces.png" width="70" height="70" alt="" />
                <h3 class="title-color mb-3" style="float: left; margin-top: 25px;">Enlaces de interés</h3>
            </div>
            @foreach ($linksArray->chunk(3) as $links)
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                @foreach ($links as $link)
                <a href="{{ $link->url_redirect }}" target="_blank"><img src="{{ $link->url_icon }}" width="20"
                        alt="">{{
                    $link->title }}<i class="fas fa-chevron-right"></i></a>
                @endforeach
            </div>
            @endforeach
        </div>
    </div>
</div>



<section id="casos" class="">
    <div class="container">
        <div class="row aos-init aos-animate" data-aos="zoom-in">
            <div id="caseCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    @foreach ($sliders as $key=>$slider)
                    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="{{  $key }}"
                        aria-current="{{ $key === 1 ? 'true' : '' }}" aria-label="Slide {{ $key }}"
                        class="{{ $key === 0 ? 'active'  : '' }}"></button>
                    @endforeach
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/192/escuela-segura" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/1.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/192/escuela-segura" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/1.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://wasichay.perueduca.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/3.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.perueduca.pe/#/home" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/4.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.gob.pe/minedu" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/5.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://escale.minedu.gob.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/6.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.gob.pe/pronabec" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/7.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/8.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://evaluaciondocente.perueduca.pe/ascenso2021/" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/9.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/120/qali-warma" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/11.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://umc.minedu.gob.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/12.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://www.siseve.pe/Web/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/13.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#caseCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#caseCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
</section>




<!-- ======= Casos de exito Section ======= -->
{{-- <section id="casos" class="">
    <div class="container">
        <div class="row aos-init aos-animate" data-aos="zoom-in">
            <div class="owl-carousel owl-theme">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/192/escuela-segura" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/1.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/192/escuela-segura" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/1.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://wasichay.perueduca.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/3.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.perueduca.pe/#/home" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/4.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.gob.pe/minedu" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/5.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://escale.minedu.gob.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/6.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://www.gob.pe/pronabec" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/7.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/8.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="https://evaluaciondocente.perueduca.pe/ascenso2021/" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/9.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://ugelilo.edu.pe/web/noticias/120/qali-warma" target="_blank"
                                data-gallery="portfolioGallery" class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/11.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://umc.minedu.gob.pe/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/12.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <div class="ml-2 mr-2 text-center">
                            <a href="http://www.siseve.pe/Web/" target="_blank" data-gallery="portfolioGallery"
                                class="portfolio-lightbox preview-link" title="">
                                <img src="assets/img/enlaces/13.jpg" class="img-fluid" alt=""><i class="bx bx-plus"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target=".owl-carousell"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target=".owl-carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
</section> --}}
<!-- End Casos Section -->
<div class="container mb-5 mt-3" id="accesosdirectos">
    <div class="row">
        <div class="col-md-3 text-center mb-2"><a href="{{ route('home.announcements') }}" class="btn"><i
                    class="fas fa-bullhorn"></i> Convocatorias CAS</a></div>
        <div class="col-md-3 text-center mb-2"><a href="https://pandora.pe/ugel/control-interno" class="btn"><i
                    class="far fa-folder-open"></i> Sistema de control interno</a></div>
        <div class="col-md-3 text-center mb-2"><a href="{{ route('home.document') }}" class="btn"><i class="far fa-file"
                    aria-hidden="true"></i> Documentos generales</a></div>
    </div>
</div>

<div class="container mb-5">
    <div class="row">
        <div class="col-lg-9">
            <!-- CONVOCATORIAS CAS-->

            <div class="card-header">
                Convocatorias CAS
                <a class="pull-right" href="#">Ver todas&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>

            </div>

            <!-- NOTICIAS-->
            <div class="card-header mt-4">
                Normatividad
                <a class="pull-right" href="#">Ver todas las noticias&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="small text-muted">10/11/21</div>
                        <h2 class="card-title h4">CAS Nº.013-2021-UGEL ILO-AGA-PER</h2>
                        <p class="card-text">28 Oct, 2021 - 08:19 pm RESULTADOS FINALES</p>
                        <a href="post.html" class="stretched-link"><i class="bi bi-app"></i>
                            Ver/Descargar&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                    </div>
                </div>

            </div>

            <!-- NORMATIVIDAD-->
            <div class="card-header mt-4">
                Noticias
                <a class="pull-right" href="#">Ver todo normatividad&nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="row g-0 rounded overflow-hidden flex-md-row h-md-250 position-relative mb-4 pt-2">
                            <div class="col-auto d-none d-lg-block">
                                <img class="card-img-top-news" src="https://pandora.pe/ugel/assets/img/noticias/1.jpg"
                                    alt="..." />
                            </div>
                            <div class="col d-flex flex-column position-static">
                                <div class="mb-1 text-muted">10/11/21</div>
                                <h4 class="card-title h4">CONCURSO DE SISEVE</h4>

                                <p class="card-text">Inscríbete en el Concurso de Tik Tok "Ileño Creativo, le dice
                                    No a la Violencia". Conoce los requisitos y más.</p>
                                <a href="noticias.php?id=1" class="stretched-link">Ver/Descargar&nbsp;&nbsp;<i
                                        class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="row g-0 rounded overflow-hidden flex-md-row h-md-250 position-relative mb-4 pt-2">
                            <div class="col-auto d-none d-lg-block">
                                <img class="card-img-top-news" src="https://pandora.pe/ugel/assets/img/noticias/1.jpg"
                                    alt="..." />
                            </div>
                            <div class="col d-flex flex-column position-static">
                                <div class="mb-1 text-muted">10/11/21</div>
                                <h4 class="card-title h4">CONCURSO DE SISEVE</h4>

                                <p class="card-text">Inscríbete en el Concurso de Tik Tok "Ileño Creativo, le dice
                                    No a la Violencia". Conoce los requisitos y más.</p>
                                <a href="noticias.php?id=1" class="stretched-link">Ver/Descargar&nbsp;&nbsp;<i
                                        class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <div class="card-body">
                        <div class="row g-0 rounded overflow-hidden flex-md-row h-md-250 position-relative mb-4 pt-2">
                            <div class="col-auto d-none d-lg-block">
                                <img class="card-img-top-news" src="https://pandora.pe/ugel/assets/img/noticias/1.jpg"
                                    alt="..." />
                            </div>
                            <div class="col d-flex flex-column position-static">
                                <div class="mb-1 text-muted">10/11/21</div>
                                <h4 class="card-title h4">CONCURSO DE SISEVE</h4>

                                <p class="card-text">Inscríbete en el Concurso de Tik Tok "Ileño Creativo, le dice
                                    No a la Violencia". Conoce los requisitos y más.</p>
                                <a href="noticias.php?id=1" class="stretched-link">Ver/Descargar&nbsp;&nbsp;<i
                                        class="fas fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <div class="col-lg-3">
            <h class="title-color">Enlaces de interés</h>
            <hr />
            <div class="col-md-12 border p-3 mb-4">
                <img class="mt-1" src="assets/img/enlaces/1_1.png" width="100%">
                <img class="mt-1" src="assets/img/enlaces/1_2.png" width="100%">
            </div>
            <a class="btn btn-outline-primary w-100 mb-5" href="filtro-noticias.html">Ver todas las noticias →</a>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <img src="assets/img/articulo-3950ffba1f.jpg" width="100%">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
{{-- <script src="js/scripts.js"></script> --}}<script
    src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
{{-- <script src="{{ url('plugins/js/jquery/jquery.min.js') }}"></script> --}}
<script src="{{ asset('js/owl.carousel.js') }}"></script>
<script>
    $(document).ready(function() {
$('#myCarousel').owlCarousel({
            autoplay: false,
      autoplayHoverPause: true,
      nav: true,
      dots: false,
      loop: false,
      margin: 10,
      responsiveClass: true,
    });

})


$(document).ready(function() {

var myModal = new bootstrap.Modal(document.getElementById('exampleModal'), {

})
myModal.show();



})
</script>
@endsection
