<?php

use App\Company;

function getCompanyData()
{
    return Company::first();
}
