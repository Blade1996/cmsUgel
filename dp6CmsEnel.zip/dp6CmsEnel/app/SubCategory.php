<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
    protected $table = 'sub_category';

    public function section()
    {
        return $this->belongsTo('App\Section', 'section_id', 'id', 'name');
    }
}
