<?php

namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\SubCategory;
use Illuminate\Support\Facades\Session;

class SubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Session::put('page', 'sub-category');
        $subCategories = SubCategory::get();
        $companyData = getCompanyData();
        return view('admin.subCategory.subCategories')->with(compact('subCategories', 'companyData'));
    }


    public function addSubCategory(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->all();
            /* echo '<pre>'; print_r($data['sectionName']); die; */

            $section = new Section;

            $rulesData = [
                'sectionName' => 'required|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoTitle' => 'nullable|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoDescription' => 'nullable|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionTextLink' => 'nullable|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoImage' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ];

            $customMessage = [
                'sectionName.required' => 'El campo nombre es requerido',
                'sectionName.regex' => 'El campo nombre no es válido',
                'sectionTextLink.regex' => 'El campo link texto no es válido',
                'sectionSeoTitle.regex' => 'El campo titulo SEO no es válido',
                'sectionSeoDescription.regex' => 'El campo descripcion SEO no es válido',
                'sectionSeoImage.mimes' => 'Formato invalido, formatos soportados: jpeg, png, jpg, gif, svg',
                'sectionSeoImage.max' => 'La imagen no debe pesar mas de 2MB',
            ];

            $this->validate($request, $rulesData, $customMessage);

            $slugClean = $section->cleanSlug(strtolower($data['sectionName']));
            $slug = strtr(strtolower($slugClean), ' ', '-');

            if ($request->hasFile('sectionSeoImage')) {
                $image_tmp = $request->file('sectionSeoImage');
                if ($image_tmp->isValid()) {
                    // Upload Images after Resize
                    $extension = $image_tmp->getClientOriginalExtension();
                    $fileName = rand(111, 99999) . '.' . $extension;
                    $large_image_path = 'images/admin_images/' . $fileName;
                    Image::make($image_tmp)->save($large_image_path);
                    $section->image_seo = env('URL_DOMAIN') . '/' . $large_image_path;
                }
            }

            $section->name = $data['sectionName'];
            $section->description = htmlspecialchars_decode(e($data['sectionDescription']));
            $section->slug = $slug;
            $section->route = $slug;
            $section->title_seo = $data['sectionSeoTitle'];
            $section->text_link = $data['sectionTextLink'];
            $section->content_seo = $data['sectionSeoDescription'];
            $section->order = Section::count() + 1;
            $section->order_home = Section::count() + 1;
            $section->save();

            $message = 'La Seccion se agrego correctamente';
            Session::flash('success_message', $message);
            return redirect()->route('dashboard.subcategories.index');
        }
        $companyData = getCompanyData();
        return view('admin.subCategory.edit_subCategory', compact('companyData'));
    }

    public function editSubCategory(Request $request, $id = null)
    {
        if ($request->isMethod('post')) {
            $data = $request->all();
            /*   echo '<pre>';
            print_r($data);
            die;
 */
            $rulesData = [
                'sectionName' => 'required|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoTitle' => 'nullable|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoDescription' => 'nullable|regex:/^[A-Za-zá-úÁ-ÚñÑ0-9\-! ,&\'\"\/@\.:\(\)]+$/',
                'sectionSeoImage' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ];

            $customMessage = [
                'sectionName.required' => 'El campo nombre es requerido',
                'sectionName.regex' => 'El campo nombre no es válido',
                'sectionSeoTitle.regex' => 'El campo titulo SEO no es válido',
                'sectionSeoDescription.regex' => 'El campo titulo SEO no es válido',
                'sectionSeoImage.mimes' => 'Formato invalido, formatos soportados: jpeg, png, jpg, gif, svg',
                'sectionSeoImage.max' => 'La imagen no debe pesar mas de 2MB',
            ];

            $this->validate($request, $rulesData, $customMessage);

            $subCategory = new SubCategory();
            $slugClean = $subCategory->cleanSlug(strtolower($data['sectionName']));
            $slug = strtr(strtolower($slugClean), ' ', '-');

            if ($request->hasFile('sectionSeoImage')) {
                $image_tmp = $request->file('sectionSeoImage');
                if ($image_tmp->isValid()) {
                    // Upload Images after Resize
                    $extension = $image_tmp->getClientOriginalExtension();
                    $fileName = rand(111, 99999) . '.' . $extension;
                    $large_image_path = 'images/admin_images/' . $fileName;
                    Image::make($image_tmp)->save($large_image_path);
                    $completePathSeo = env('URL_DOMAIN') . '/' . $large_image_path;
                }
            } else if (!empty($data['currentSectionSeoImage'])) {
                $completePathSeo = $data['currentSectionSeoImage'];
            } else {
                $completePathSeo = '';
            }

            SubCategory::where(['id' => $id])->update(['name' => $data['sectionName'], 'slug' => $slug, 'route' => $slug, 'description' => htmlspecialchars_decode(e($data['sectionDescription'])), 'text_link' => $data['sectionTextLink'], 'order' => $data['sectionOrder'], 'order_home' => $data['sectionOrderHome'], 'title_seo' => $data['sectionSeoTitle'], 'content_seo' => $data['sectionSeoDescription'], 'image_seo' => $completePathSeo]);

            $message = 'La Seccion se actualizo correctamente';
            Session::flash('success_message', $message);
            return redirect()->route('dashboard.subcategories.index');
        }
        $companyData = getCompanyData();
        $sectionDetail = SubCategory::where(['id' => $id])->first();
        return view('admin.subCategory.edit_subCategory')->with(compact('sectionDetail', 'companyData'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteSubCategory($id)
    {
        SubCategory::find($id)->delete();
        $message = 'El Submenu se elimino correctamente';
        Session::flash('success_message', $message);
        return redirect()->route('dashboard.subcategories.index');
    }
}
