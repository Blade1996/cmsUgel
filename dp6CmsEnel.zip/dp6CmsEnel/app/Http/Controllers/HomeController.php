<?php

namespace App\Http\Controllers;

use App\Article;
use App\Section;
use App\Documents;
use App\Announcement;
use App\InterestLink;
use Illuminate\Http\Request;


class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $companyData = getCompanyData();
        $sections = Section::get();
        $links = InterestLink::get();
        $collection = collect($links);
        $linksArray = $collection;
        $linksArray->toArray();
        $slider = Article::where('show_slider', true)->orderBy('order')->get();
        return view('frontend.home')->with(['companyData' => $companyData, 'sections' => $sections, 'linksArray' => $linksArray, 'sliders' => $slider]);
    }

    public function indexDocuments()
    {
        $documents = Documents::get();
        $sections = Section::get();
        $companyData = getCompanyData();
        return view('frontend.documents')->with(compact('documents', 'companyData', 'sections'));
    }

    public function indexAnnouncements()
    {
        $announcements = Announcement::get();
        $sections = Section::get();
        $companyData = getCompanyData();
        return view('frontend.announcements')->with(compact('announcements', 'companyData', 'sections'));
    }

    public function indexContact()
    {
        $sections = Section::get();
        $companyData = getCompanyData();
        return view('frontend.contact')->with(compact('companyData', 'sections'));
    }
}
