<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        '/admin/dashboard/verify-curr-pwd',
        '/admin/dashboard/upd-section-status',
        '/admin/dashboard/slider/upd-slider-order',
        '/admin/dashboard/units/order'
    ];
}
